﻿using System;

namespace DefiningClasses
{
   public class StartUp
    {
       public static void Main(string[] args)
        {
            string name = "Pesho";
            int age = 20;

            Person pesho = new Person()
            {
                Name = name,
                Age = age
            };

            Console.WriteLine($"{pesho.Name} {pesho.Age}");
        }
    }
}
