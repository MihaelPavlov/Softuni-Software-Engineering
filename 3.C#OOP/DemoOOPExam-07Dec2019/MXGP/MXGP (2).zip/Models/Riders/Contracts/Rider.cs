﻿using System;
using System.Collections.Generic;
using System.Text;
using MXGP.Models.Motorcycles.Contracts;
using MXGP.Utilities.Messages;

namespace MXGP.Models.Riders.Contracts
{
    public class Rider : IRider
    {
        private string name;
        public Rider(string name)
        {
            this.Name = name;
            this.CanParticipate = false;
        }
        public string Name
        {
            get
            {
                return this.name;
            }
          private  set
            {
                if (string.IsNullOrEmpty(value) || value.Length < 5)
                {
                    throw new ArgumentException(string.Format(ExceptionMessages.InvalidName, value, 5));
                }
                this.name = value;
            }
        }

        public IMotorcycle Motorcycle { get; set; }

        public int NumberOfWins { get; set; }

        public bool CanParticipate { get; set; }
       

        public void AddMotorcycle(IMotorcycle motorcycle)
        {
            if (motorcycle == null)
            {
                throw new ArgumentException(ExceptionMessages.MotorcycleInvalid);
            }
            this.Motorcycle = motorcycle;
            this.CanParticipate = true;
        }

        public void WinRace()
        {
            this.NumberOfWins++;
        }
    }
}
