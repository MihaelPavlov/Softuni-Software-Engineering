﻿using MortalEngines.Core;
using MortalEngines.Entities;

namespace MortalEngines
{
    public class StartUp
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}