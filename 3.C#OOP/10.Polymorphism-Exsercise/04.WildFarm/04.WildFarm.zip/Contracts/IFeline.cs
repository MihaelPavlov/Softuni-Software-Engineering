﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Contracts
{
  public  interface IFeline :IMammal
    {
         string Breed { get;}
    }
}
