﻿using _01.Vihicles.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vihicles.Core
{
    public class Engine
    {

        public void Run()
        {
            var inputForCar = Console.ReadLine().Split();
            double fuelQuantity = double.Parse(inputForCar[1]);
            double fuelConsumption = double.Parse(inputForCar[2]);
            var car = new Car(fuelQuantity, fuelConsumption);

            var inputForTruck = Console.ReadLine().Split();
            double fuelQuantityTruck = double.Parse(inputForTruck[1]);
            double fuelConsumptionTruck = double.Parse(inputForTruck[2]);
            var truck = new Truck(fuelQuantityTruck, fuelConsumptionTruck);

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine().Split();
                if (input[1]==nameof(Car))
                {
                    ExcecuteCommand(car, input[0], double.Parse(input[2]));
                }
                else if (input[1] == nameof(Truck))
                {
                    ExcecuteCommand(truck, input[0], double.Parse(input[2]));
                }
            }

            Console.WriteLine(car.ToString());  
            Console.WriteLine(truck.ToString());  
        }

        private static void ExcecuteCommand(Vehicle vehicle ,string command , double value)
        {
            if (command=="Refuel")
            {
                vehicle.Refuel(value);
            }
            else if (command=="Drive")
            {
                Console.WriteLine(vehicle.Drive(value));
                
            }
        }
    }
}
