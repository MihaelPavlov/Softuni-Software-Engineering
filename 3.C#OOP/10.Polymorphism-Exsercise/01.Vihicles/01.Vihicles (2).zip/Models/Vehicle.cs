﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vihicles.Models
{
   public abstract class Vehicle
    {
        public Vehicle(double fuelQuantity , double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }
        public double FuelQuantity { get; set; }
        public double FuelConsumption { get; set; }

        protected abstract double AdditionalConsumption { get; }
        public virtual string Drive( double distance)
        {
            double neededFuel = (FuelConsumption + this.AdditionalConsumption) * distance;

            if (neededFuel<=this.FuelQuantity)
            {
                this.FuelQuantity -= neededFuel;
                return $"{this.GetType().Name} travelled {distance} km";
            }

            return $"{this.GetType().Name} needs refueling";
        }
        public virtual void Refuel( double litters)
        {
            FuelQuantity += litters;
        }
        public override string ToString()
        {
            return $"{this.GetType().Name}: {FuelQuantity:F2}";
        }
    }
}
