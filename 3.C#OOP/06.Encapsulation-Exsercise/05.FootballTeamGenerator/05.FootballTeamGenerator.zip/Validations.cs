﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.FootballTeamGenerator
{
   public static class Validations
    {
        public  const int MIN_VALUE = 0;
        public  const int MAX_VALUE = 100;
     //   public const string  "A name should not be empty.";
    }
}
