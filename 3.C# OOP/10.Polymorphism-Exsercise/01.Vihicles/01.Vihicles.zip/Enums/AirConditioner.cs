﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Vihicles.Enums
{
   public enum AirConditioner
    {
        on=1,
        off=2
    }
}
