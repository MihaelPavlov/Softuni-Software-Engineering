﻿using _01.Vihicles.Models;
using _01.Vihicles.Core;
using System;

namespace _01.Vihicles
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
          
        }
    }
}
