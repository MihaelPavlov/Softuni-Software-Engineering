﻿using SpaceStation.Models.Planets;
using SpaceStation.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpaceStation.Repositories
{
   public class PlanetRepository : IRepository<Planet>
    {
        private readonly List<Planet> models;
        public PlanetRepository()
        {
            this.models = new List<Planet>();
        }
        public IReadOnlyCollection<Planet> Models => this.models.AsReadOnly();

        public void Add(Planet model)
        {

            //TODO : CHECK for unique planet name;
            this.models.Add(model);

        }

        public Planet FindByName(string name)
        {
            return this.models.FirstOrDefault(p=>p.Name== name);
        }

        public bool Remove(Planet model)
        {
            return this.models.Remove(model);
        }
    }
}
