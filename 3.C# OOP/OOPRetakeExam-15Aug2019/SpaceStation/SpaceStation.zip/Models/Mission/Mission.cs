﻿using System;
using System.Collections.Generic;
using System.Text;
using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Models.Planets;

namespace SpaceStation.Models.Mission
{
    public class Mission : IMission
    {
        public void Explore(IPlanet planet, ICollection<IAstronaut> astronauts)
        {

            while (planet.Items.Count != 0)
            {
                foreach (var item in planet.Items)
                {
                    foreach (var astronaut in astronauts)
                    {
                        if (!astronaut.CanBreath)
                        {
                            continue;
                        }
                        astronaut.Breath();
                        astronaut.Bag.Items.Add(item);
                        planet.Items.Remove(item);
                        break;


                    }
                    break;

                }
            }

        }
    }
}
