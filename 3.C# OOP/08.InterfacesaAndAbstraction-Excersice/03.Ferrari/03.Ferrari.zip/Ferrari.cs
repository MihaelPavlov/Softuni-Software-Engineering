﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Ferrari
{
    public class Ferrari : ICar
    {
        public string Driver { get ; set ; }
    }
}
