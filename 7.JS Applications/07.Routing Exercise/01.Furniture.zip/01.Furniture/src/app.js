import page from "../node_modules/page/page.mjs";

import { render } from "../node_modules/lit-html/lit-html.js";


import { dashboardPage } from "./views/dashboard.js";
import { detailsPage } from "./views/details.js";
import { createPage } from "./views/create.js";
import { editPage } from "./views/edit.js";
import { registerPage } from "./views/register.js";
import { loginPage } from "./views/login.js";
import { myPage } from "./views/myFurniture.js";

import {logout}  from "./api/data.js";

const main = document.querySelector(".container");

page("/", decorateContext, dashboardPage);
page("/my-furniture", decorateContext, myPage);
page("/details/:id", decorateContext, detailsPage);
page("/create", decorateContext, createPage);
page("/edit/:id", decorateContext, editPage);
page("/register", decorateContext, registerPage);
page("/login", decorateContext, loginPage);

//start Application
document.getElementById("logoutBtn").addEventListener("click", async () => {
  await logout();
  setUserNav();
  page.redirect("/");
});
setUserNav();
page.start();

// ctx->context come from page
function decorateContext(ctx, next) {
  console.log(`this is the renderMiddleware context -> ${ctx} next ->${next}`);
  ctx.render = (content) => render(content, main);
  ctx.setUserNav = setUserNav;
  next();
}
function setUserNav(ctx, next) {
  const userId = sessionStorage.getItem("userId");
  if (userId != null) {
    document.getElementById("user").style.display = "inline-block";
    document.getElementById("guest").style.display = "none";
  } else {
    document.getElementById("user").style.display = "none";
    document.getElementById("guest").style.display = "inline-block";
  }
}
