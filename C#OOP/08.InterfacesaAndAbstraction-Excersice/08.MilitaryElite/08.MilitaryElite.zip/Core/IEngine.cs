﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.MilitaryElite.Core
{
  public  interface IEngine
    {
        void Run();
    }
}
