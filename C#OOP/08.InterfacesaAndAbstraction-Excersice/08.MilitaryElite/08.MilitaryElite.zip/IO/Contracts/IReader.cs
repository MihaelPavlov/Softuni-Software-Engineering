﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.MilitaryElite.IO.Contracts
{
   public interface IReader
    {
        string ReadLine();
    }
}
