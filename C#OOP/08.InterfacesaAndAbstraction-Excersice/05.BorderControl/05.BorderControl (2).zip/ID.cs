﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BorderControl
{
  public  interface ID 
    {
        public string Id { get; set; }

        public string Birthday { get; set; }


    }
}
