﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _05.BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            RunProgram.Run();

            RunProgram.Output();
        }
    }
}
