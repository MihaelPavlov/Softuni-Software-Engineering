﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _05.BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine().Split(" ");
            List<ID> all = new List<ID>();
            while (input[0]!="End")
            {

                string name = input[0];
                if (input.Length==2)
                {
                    string id =input[1];
                    Robots robot = new Robots(name, id);
                    all.Add(robot);

                }
                else if (input.Length==3)
                {
                    int age = int.Parse(input[1]);
                    string id =input[2];

                    Citizens citizens = new Citizens(name, age, id);

                    all.Add(citizens);


                }




                input = Console.ReadLine().Split(" ");
            }

            int lastNumber =int.Parse(Console.ReadLine());

            foreach (var creature in all)
            {
                int lenght = lastNumber.ToString().Length;
                var lastLenght = creature.Id.Substring((creature.Id.Length-1)-lenght+1, lenght);
                    
                if (int.Parse(lastLenght) == lastNumber)
                {
                    Console.WriteLine(creature.Id);
                }
            }
        }
    }
}
