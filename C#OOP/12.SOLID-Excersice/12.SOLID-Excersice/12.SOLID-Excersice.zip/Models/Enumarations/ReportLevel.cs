﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _12.SOLID_Excersice.Models.Enumarations
{
    public enum ReportLevel
    {
        Info=1,
        Warning=2,
        Error=3,
        Critical=4,
        Fatal=5,
        
    }
}
