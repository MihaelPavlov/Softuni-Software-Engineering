﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _12.SOLID_Excersice
{
    public interface ILayout
    {
        string Format { get; }
    }
}
