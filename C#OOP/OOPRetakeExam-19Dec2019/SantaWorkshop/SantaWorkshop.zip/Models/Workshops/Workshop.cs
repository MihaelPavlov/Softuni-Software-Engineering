﻿using SantaWorkshop.Models.Dwarfs.Contracts;
using SantaWorkshop.Models.Presents.Contracts;
using SantaWorkshop.Models.Workshops.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace SantaWorkshop.Models.Workshops
{
    public class Workshop : IWorkshop
    {
        public void Craft(IPresent present, IDwarf dwarf)
        {
            foreach (var instrument in dwarf.Instruments)
            {
                if (dwarf.Energy <= 0)
                {
                    return;
                }
                if (instrument.IsBroken())
                {
                    continue;
                }

                while (!present.IsDone())
                {
                    if (dwarf.Energy == 0)
                    {
                        return;
                    }
                    if (instrument.IsBroken())
                    {
                        
                        break;
                    }
                    present.GetCrafted();
                    dwarf.Work();
                    instrument.Use();
                    if (present.IsDone())
                    {
                        return;
                    }
                }

            }


        }
    }
}
